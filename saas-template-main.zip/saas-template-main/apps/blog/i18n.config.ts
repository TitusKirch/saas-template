import { baseConfig } from '@tituskirch/app-base/i18n.config'

export default defineI18nConfig(() => baseConfig)
