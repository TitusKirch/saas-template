<template>
  <div>Blog with a cool new change. Yeah!</div>
</template>
