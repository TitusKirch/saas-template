import histoireConfig from '../../packages/app-base/histoire.config'
export default histoireConfig
