export const classes = {
  global: {
    outer: 'max-w-none',
  },
}
