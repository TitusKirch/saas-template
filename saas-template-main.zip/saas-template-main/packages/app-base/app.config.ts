export default defineAppConfig({
  ui: {
    primary: 'teal',
    gray: 'zinc',
  },
})
